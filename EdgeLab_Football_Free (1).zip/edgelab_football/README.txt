EDGELAB FOOTBALL — FREE LOCAL VERSION

This dashboard shows fixtures and scores from a public ESPN scoreboard feed. No API key is needed. It does not include betting odds.

WINDOWS SETUP
1. Extract this ZIP to Downloads.
2. Open the extracted edgelab_football folder.
3. Click the File Explorer address bar, type cmd, and press Enter.
4. In the black command window, type: npm install
5. When it finishes, type: npm start
6. Open http://localhost:3000 in Chrome.
7. Keep the black command window open while using the dashboard.

REQUIREMENT
Install Node.js LTS from https://nodejs.org if npm is not recognized, then reopen the command window.

LIMITATIONS
This is a local site on your computer, not a public website. Public data feed availability and coverage may change. No odds or betting predictions are provided. Missing data must not be treated as a score of zero or a confirmed result.
