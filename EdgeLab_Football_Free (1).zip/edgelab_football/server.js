import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
const app = express();
const port = Number(process.env.PORT || 3000);
const here = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(here, "public")));
const leagues = {
 "eng.1":"Premier League","esp.1":"La Liga","ita.1":"Serie A","ger.1":"Bundesliga",
 "fra.1":"Ligue 1","usa.1":"MLS","uefa.champions":"UEFA Champions League","uefa.europa":"UEFA Europa League"
};
app.get("/api/leagues", (_req,res)=>res.json(Object.entries(leagues).map(([id,name])=>({id,name}))));
app.get("/api/scoreboard", async (req,res)=>{
 const league=String(req.query.league||"eng.1");
 if(!Object.hasOwn(leagues,league)) return res.status(400).json({error:"Unsupported competition."});
 const date=String(req.query.date||"");
 const url=new URL(`https://site.api.espn.com/apis/site/v2/sports/soccer/${league}/scoreboard`);
 if(/^\d{8}$/.test(date)) url.searchParams.set("dates",date);
 try{
  const response=await fetch(url);
  if(!response.ok) throw new Error(`Data source returned HTTP ${response.status}`);
  const raw=await response.json();
  const events=(raw.events||[]).map(e=>{
   const c=e.competitions?.[0], ts=c?.competitors||[];
   const h=ts.find(t=>t.homeAway==="home")||ts[0]||{}, a=ts.find(t=>t.homeAway==="away")||ts[1]||{};
   const st=e.status?.type||{};
   return {id:e.id,date:e.date||null,state:st.state||"pre",status:st.shortDetail||st.detail||"Scheduled",
    venue:c?.venue?.fullName||"",home:{name:h.team?.displayName||"Home",score:h.score??null,logo:h.team?.logo||null},
    away:{name:a.team?.displayName||"Away",score:a.score??null,logo:a.team?.logo||null}};
  });
  res.set("Cache-Control","public, max-age=60");
  res.json({league:leagues[league],fetchedAt:new Date().toISOString(),events});
 }catch(err){res.status(502).json({error:"Could not load football data right now.",detail:String(err?.message||err),hint:"Try again later; this public feed can be temporarily unavailable."});}
});
app.get("/api/health",(_req,res)=>res.json({ok:true,app:"EdgeLab Football",odds:false}));
app.listen(port,()=>console.log(`EdgeLab Football running at http://localhost:${port}`));
